/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

/**
 *
 * @author dingxiaole
 */
public class User {
    private Integer passengerNum;
    private String nowCity;

    public Integer getPassengerNum() {
        return passengerNum;
    }

    public void setPassengerNum(Integer passengerNum) {
        this.passengerNum = passengerNum;
    }

    public String getCity() {
        return nowCity;
    }

    public void setCity(String city) {
        this.nowCity = city;
    }
    
}
