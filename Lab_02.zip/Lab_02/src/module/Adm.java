/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

import java.util.Date;

/**
 *
 * @author dingxiaole
 */
public class Adm {
    private CarHistory carHistory;
    Date date;
    
    public Adm() {
        carHistory = new CarHistory();
    }

    public CarHistory getCarHistory() {
        return carHistory;
    }

    public void setCarHistory(CarHistory carHistory) {
        this.carHistory = carHistory;
    }

    public String getDate() {
        return date.toString();
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    
}
