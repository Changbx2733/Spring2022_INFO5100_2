/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

/**
 *
 * @author dingxiaole
 */
public class Car {
    private String brand;
    private Integer prodYy;
    private String carModel;
    private String licensePlate;
    private String city;
    private String owner;
    private String seatNum;
    private String isEx;
    private String isAva;
    private Integer serialNum;
    private String time;
    
    private static int count = 0;

    @Override
    public String toString() {
        return licensePlate; 
    }
    
    public Car() {
        count++;
        serialNum = count;
    }
    
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(Integer serialNum) {
        this.serialNum = serialNum;
    }

    public String getIsAva() {
        return isAva;
    }

    public void setIsAva(String isAva) {
        this.isAva = isAva;
    }
    
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Integer getProdYy() {
        return prodYy;
    }

    public void setProdYy(Integer prodYy) {
        this.prodYy = prodYy;
    }

    public String getCarModel() {
        return carModel;
    }

    public void setCarModel(String carModel) {
        this.carModel = carModel;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getSeatNum() {
        return seatNum;
    }

    public void setSeatNum(String seatNum) {
        this.seatNum = seatNum;
    }

    public String getIsEx() {
        return isEx;
    }

    public void setIsEx(String isEx) {
        this.isEx = isEx;
    }
    
    
}
