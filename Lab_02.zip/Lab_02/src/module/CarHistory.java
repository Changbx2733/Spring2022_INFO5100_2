/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author dingxiaole
 */
public class CarHistory {
    private List<Car> carHistory;
    Date date;

    public CarHistory() {
        carHistory = new ArrayList<Car>();
    }

    public List<Car> getCarHistory() {
        return carHistory;
    }

    public void setCarHistory(ArrayList<Car> history) {
        this.carHistory = history;
    }
    
    public Car addCar() {
        Car c = new Car();
        carHistory.add(c);
        return c;
    }
    
    public void removeCar(Car c) {
        carHistory.remove(c);
    }
    
    public Car searchCar(int id) {
        for (Car car : carHistory) {
            if (car.getSerialNum() == id) {
                return car;
            }
        }
        return null;
    }
}
